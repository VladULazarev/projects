<?php
/**
 * The main Controller
 */
namespace Core;

class Controller
{

}
