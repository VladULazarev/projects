<?php
// Set http or https
define("HTTP", "http://");

const AMOUNT_OF_RESETS = 3;
const AMOUNT_OF_CONTACT_MESSANGES = 3;
