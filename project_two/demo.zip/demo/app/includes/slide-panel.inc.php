<!-- SLIDE PANEL -->
	<div id='panel'>
		<div class='inner-panel'>

		<!-- Panel top container -->
			<div class='inner-panel__top-block'>

					<h2 class="pn-header">Company Name</h2>

			</div>

		<!-- Panel links -->
			<ul class='in-pn__ul'>
					<li><a class='pn-link mt-3 mb-2' href='/'><i class='fa fa-home'></i>home</a></li>

				<!-- Orders -->
					<li><a class='pn-link' href='/orders'><i class='fa fa-pencil ps-1'></i>orders</a></li>

				<!-- Other links -->
					<li><a class='pn-link' href='/buyer-protection'><i class='fa fa-lock fa-fw'></i>buyer protection</a></li>
					<li><a class='pn-link' href='/delivery-options'><i class='fa fa-truck fa-fw'></i>delivery options</a></li>
			</ul>
		</div>
	</div>
